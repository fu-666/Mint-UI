# `HTML5`新特性 - `Unit02`

# 1.`Vuex`

## · `mapState()`

`mapState()`函数用于为组件**创建计算属性**以返回`Vuex Store`中的状态，其语法结构是：

```javascript

mapState( array | object)

```

## · `mapGetters()`

`mapGetters()`函数用来为组件**创建计算属性**以返回`getter`的返回值，其语法结构是：

```javascript

mapGetters(array|object)

```

## · `mapMutations()`

`mapMutations()`函数用于为组件**创建方法**以提交`Mutation`，其语法结构是:

```javascript

mapMutations(array|object)

```

## · `mapActions()`

`mapActions()`函数用于为组件**创建方法**以分发`Action`，其语法结构是:

```javascript

mapActions(array|object)

```

# 2.`WebStorage`

## 2.1 简介

`WebStorage`为浏览器提供一种更加直接、便捷的数据存储方式。

`WebStorage`分为两种存储机制：

·`sessionStorage`，为每一个源提供独立的存储空间，`sessionStorage`存储的数据只在当前标签页有效。`sessionStorage`可通过`window.sessionStorage`属性进行访问。

·`localStorage`，为每一个源提供独立的存储空间，`localStorage`存储的数据"永远"有效。`localStorage`可通过`window.localStorage`属性进行访问。

## 2.2 方法

### ·  `setItem()`

`setItem()`方法用于指定的键名设置键值，其语法结构是：

```javascript

sessionStorage.setItem(string key,string value)

localStorage.setItem(string key,string value)

```

### ·  `getItem()`

`getItem()`方法用于根据指定的键名来返回指定的键值，如果键名不存在，则返回`NULL`，其语法结构是：

```javascript

string sessionStorage.getItem(string key)

string localStorage.getItem(string key)

```

![image-20201208095142070](assets/image-20201208095142070.png)

### ·  `removeItem()`

`removeItem()`方法用于清除指定的键名，其语法结构是：

```javascript

sessionStorage.removeItem(string key)

localStorage.removeItem(string key)

```

### ·  `clear()`

`clear()`方法用于清除所有的键名，其语法结构是：

```javascript

sessionStorage.clear()

localStorage.clear()

```

## 2.3 属性

### `length`

`length`属性用于获取`storage`中包含的成员数量，其语法结构是：

```javascript

integer sessionStorage.length

integer localStorage.length

```

# 3.音频、视频

## 3.1 视频

```html

<!-- 简捷语法 -->
<video width="宽度" height="高度" src="视频文件URL地址">
    视频格式不支持时的提示信息
</video>

<!--标准语法-->

<video width="宽度" height="高度">
    <source src="视频文件URL地址" type="视频文件MIME型"/>
    ...
    视频格式不支持时的提示信息
</video>


```

> 视频文件的格式有：`mp4`、`webm`、`ogg`
>
> `mp4`文件的`MIME`类型是：`video/mp4`
>
> `webm`文件的`MIME`类型是：`video/webm`
>
> `ogg`文件的`MIME`类型是：`video/ogg`

## 3.2 视频属性

### · `controls`

`controls`属性用于控制是否显示视频播放控件，布尔属性

### · `autoplay`

`autoplay`属性用于控制是否自动播放视频，布尔属性

> `autoplay`属性需要与`muted`属性组合使用，示例代码如下：
>
> ```html
> 
> <video src="video/video.mp4" width="640" height="360"
> 	controls autoplay muted>
> </video>
> 
> ```

### · `muted`

`muted`属性用于控制视频在播放时是否静音，布尔属性

### · `loop`

`loop`属性用于控制视频是否循环播放，布尔属性

### · `poster`

`poster`属性用于控制视频海报帧的`URL`地址

### · `preload`

`preload`属性用于控制视频的预载入方式，其值包括：

·`none`，不缓存视频数据

·`metadata`，只加载视频的总时长、宽度、高度等头数据

·`auto`，尽可能的下载视频文件，默认值

## 3.3 音频

```html

<!--简捷语法-->
<audio src="音频文件URL地址">
    音频格式不支持时的提示信息
</audio>
<!--标准语法-->
<audio>
    <source src="音频文件URL地址" type="音频文件MIME类型"/>
    ...
    音频格式不支持时的提示信息
</audio> 

```

> 音频文件格式有：`mp3`、`wav`、`ogg`
>
> `mp3`文件的`MIME`类型是：`audio/mp3`
>
> `wav`文件的`MIME`类型是：`audio/wav`
>
> `ogg`文件的`MIME`类型是：`audio/ogg`

## 3.3 音频属性

### · `controls`

`controls`属性用于控制是否显示音频播放控件，布尔属性

### · `autoplay`

`autoplay`属性用于控制是否自动播放音频，布尔属性

> `autoplay`属性需要与`muted`属性组合使用，示例代码如下：
>
> ```html
> 
> <audio src="audio/bad.mp3" controls autoplay muted>
> </audio>
> 
> ```

### · `muted`

`muted`属性用于控制音频在播放时是否静音，布尔属性

### · `loop`

`loop`属性用于控制音频是否循环播放，布尔属性


### · `preload`

`preload`属性用于控制音频的预载入方式，其值包括：

·`none`，不缓存音频数据

·`metadata`，只加载音频的总时长、宽度、高度等头数据

·`auto`，尽可能的下载音频文件，默认值

# 4.`HTMLVideoElement`接口

`HTMLVideoElement`接口用于操作视频对象（`<video>`），该接口继承自`HTMLMediaElement`和`HTMLElement`。

![image-20201208153226542](assets/image-20201208153226542.png)

## 4.1 属性

### ·  `width`

`width`属性用于获取/设置视频对象的宽度，其语法结构是：

```javascript

//设置
HTMLVideoElement.width = string value
//获取
variable = HTMLVideoElement.width

```

> 在进行获取操作时，必须保证`<video>`标签上存在`width`属性 

### ·  `height`

`height`属性用于获取/设置视频对象的高度，其语法结构是：

```javascript

//设置
HTMLVideoElement.height = string value
//获取
variable = HTMLVideoElement.height

```

> 在进行获取操作时，必须保证`<video>`标签上存在`height`属性 

### ·  `poster`

`poster`属性用于获取/设置视频海报帧的`URL`地址，其语法结构是：

```javascript

//设置
HTMLVideoElement.poster = string url
//获取
variable = HTMLVideoElement.poster

```

# 5.`HTMLAudioElement`接口

`HTMLAudioElement`接口用于操作音频对象（`<audio>`），该接口继承自`HTMLMediaElement`和`HTMLElement`。

![image-20201208163714703](assets/image-20201208163714703.png)

### 构造函数

```javascript

new Audio([string url])

```

# 6.`HTMLMediaElement`接口

`HTMLMediaElement`接口用于控制音频和视频对象。该接口继承自`HTMLElement`。

![image-20201208164444537](assets/image-20201208164444537.png)

## 6.1 属性

### ·  `controls`

`controls`属性用于获取/设置是否显示媒体的播放控件，语法结构是：

```javascript

//设置
HTMLMediaElement.controls = boolean value
//获取
variable = HTMLMediaElement.controls

```

### ·  `autoplay`

`autoplay`属性用于获取/设置媒体是否自动播放，语法结构是：

```javascript

//设置
HTMLMediaElement.autoplay = boolean value
//获取
variable = HTMLMediaElement.autoplay

```

### ·  `muted`

`muted`属性用于获取/设置媒体是否静音播放，语法结构是：

```javascript

//设置
HTMLMediaElement.muted = boolean value
//获取
variable = HTMLMediaElement.muted

```

### ·  `loop`

`loop`属性用于获取/设置媒体是否循环播放，语法结构是：

```javascript
//设置
HTMLMediaElement.loop = boolean value
//获取
variable = HTMLMediaElement.loop

```

### ·  `preload`

`preload`属性用于获取/设置媒体的预载入方式，语法结构是：

```javascript

//设置
HTMLMediaElement.preload = string 'none|metadata|auto'
//获取
variable = HTMLMediaElement.preload

```

### ·  `src`

`src`属性用于获取/设置媒体文件的`URL`地址，语法结构是：

```javascript

//设置
HTMLMediaElement.src = string value
//获取
variable = HTMLMediaElement.src

```

### ·  `paused`

`paused`属性用于获取媒体是否正在暂停，语法结构：

```javascript

boolean HTMLMediaElement.paused

```

### ·  `ended`

`ended`属性用于获取媒体是否已经播放完毕，其语法结构是：

```javascript

boolean HTMLMediaElement.ended

```

### ·  `volume`

`volume` 属性用于获取/设置媒体的音量，其值为`0`(表示静音)~`1`(表示最大音量)，其语法结构是：

```javascript

//设置
HTMLMediaElement.volume = double value
//获取
variable = HTMLMediaElement.volume

```



## 6.2 方法

### · `play()`

`play()`方法用于实现播放媒体，其语法结构是：

```javascript

HTMLMediaElement.play()

```

### · `pause()`

`pause()`方法用于实现暂停媒体，其语法结构是：

```javascript

HTMLMediaElement.pause()

```



## 6.3 事件



